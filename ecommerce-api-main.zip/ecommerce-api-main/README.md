Ecommerce API
=====

ecommerce-api is a Django app to conduct Web-based ecommerce site.

Quick start
-----------

1. After installing, run ``python manage.py migrate``.

2. Start the development server ``python manage.py runserver`` and visit http://127.0.0.1:8000/admin/
   to create models (you'll need the Admin app enabled).

3. Visit http://127.0.0.1:8000/ to reach other urls.

4. Visit http://127.0.0.1:8000/swagger to use Swagger.